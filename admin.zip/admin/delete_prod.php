<?php
	include 'includes/config.php';
	$id = $_REQUEST['id'];
		$query = "DELETE FROM itemtb WHERE product_id = '$id'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\"Successfully Deleted\");
					window.location.href = \"product.php\"
				</script>";
	}
	else {

		echo "<script type = \"text/javascript\">
        alert(\"Not Deleted\");
        window.location.href = \"product.php\"
    </script>";
	}
?>
