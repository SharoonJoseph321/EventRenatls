<?php
	include 'includes/config.php';
	$id = $_REQUEST['id'];
		$query = "DELETE FROM categorytb WHERE cat_id = '$id'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\"Successfully Deleted\");
					window.location.href = \"category.php\"
				</script>";
	}
	else {

		echo "<script type = \"text/javascript\">
        alert(\"Not Deleted\");
        window.location.href = \"category.php\"
    </script>";
	}
?>
