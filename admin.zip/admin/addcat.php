 
 
 
 <head>
    <meta charset="utf-8">
    <title>Event Essentials</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">



    <style>
    .scontainer{
        
        max-width: 600px;
        margin: auto;
        height: 50vh;

    }
        </style>


</head>

 
 
 
 <body>
 <?php
						if(isset($_POST['save'])){
							include 'includes/config.php';
							$cat_name = $_POST['cat_name'];
							$image = basename($_FILES['image']['name']);
                            $target_path = "../cat_images/";
                            $target_path = $target_path . basename ($_FILES['image']['name']);
                           
                            $sqry = "SELECT * FROM categorytb WHERE cat_name = '$cat_name'";
                            $result1 = $conn->query($sqry);
                            
                            if ($result1->num_rows > 0) {
                                echo "<script type=\"text/javascript\">
                                        alert('Category Name Exists. Try Again');
                                        window.location.href = 'category.php';
                                      </script>";
                                exit;
                            }
                            
                            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
                                $qry = "INSERT INTO categorytb (cat_name, image)
                                        VALUES ('$cat_name', '$image')";
                                $result = $conn->query($qry);
                            
                                if ($result == TRUE) {
                                    echo "<script type=\"text/javascript\">
                                            alert(\"Saved successfully.\");
                                            window.location = \"category.php\";
                                          </script>";
                                    exit;
                                } else {
                                    echo "<script type=\"text/javascript\">
                                            alert(\"Not saved. Failed. Try Again\");
                                            window.location = \"category.php\";
                                          </script>";
                                    exit;
                                }
                            }
                        }
                        ?>                            
 
                  <section>
                    <form action="" method="post"enctype="multipart/form-data">
                 <div class="scontainer col-sm-12 col-xl-6">
                        <div class="bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Add New Category</h6>
                            
                            <div class="mb-3">
                                <label for="formFileMultiple" class="form-label">Category Name</label>
                                <input class="form-control bg-dark" type="text" name="cat_name">
                            </div>
                            <div class="mb-3">
                                <label for="formFile" class="form-label">Insert Image</label>
                                <input class="form-control bg-dark" type="file"  name="image">
                            </div>
                            <div class="d-flex justify-content-center">
                             <button type="submit" name="save"class="btn btn-success btn-block btn-sm gradient-custom-4 text-body">Save</button>
                            </div>

                        </div>
                  </div>
                    </form>
</section>
</body>