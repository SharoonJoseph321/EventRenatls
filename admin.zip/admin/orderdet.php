 
 <html>
 
 <head>
    <meta charset="utf-8">
    <title>Event Essentials</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <script type="text/javascript">
		function sureToApprove(id){
			if(confirm("Are you sure you want to confirm this Order ? ")){
				window.location.href ='confirmorder.php?id='+id;
			}
        }
            function sureToApprovee(id){
			if(confirm("Are you sure you want to Decline this Order ? ")){
				window.location.href ='declinedorder.php?id='+id;
			}
		}
    function sureToApproveel(id){
			if(confirm("Are you sure you want to Restack this Order stocks ? ")){
				window.location.href ='restackorder.php?id='+id;
			}
		}
	</script>

    <style>
    .scontainer{
        
        max-width: 600px;
        margin: auto;
        height: 50vh;

    }
        </style>

</head>

 
 
 
 <body>
 

								
 
        
                <div class="bg-secondary text-center rounded p-4">
                  <section>
                  <div class="scontainer col-sm-12 col-xl-6">
                  <table class="table table-light table-bordered table-hover text-center mb-0">
                  <thead>
                      <tr class="text-white">
                          <th>Category</th>
                          <th>Product</th>
                          <th>Quantity</th>
                      </tr>
                  </thead>
                  <?php
                  include 'includes/config.php';
                 
                
                
                 $select1 = "SELECT * FROM order_details WHERE  order_id = '$_GET[id]'";
                 $result1 = $conn->query($select1);
                 while($row1 = $result1->fetch_assoc()){   
                 $p_id=$row1['product_id']; 
                
                 $select2 = "SELECT * FROM itemtb WHERE product_id = '$p_id'";
                  $result2 = $conn->query($select2);
                  while($row2 = $result2->fetch_assoc()){
                ?>
                 
                  <tbody>
                      <tr>
                          <td> <?php echo $row2['cat_id'];?> </td>
                          <td> <?php echo $row2['name'];?></td>
                          <?php 
                        } ?>
                          <td > <?php echo $row1['prod_qty'];?> </td>
                          
                          <?php
                          $oid = $_GET['id'];
                        } ?>
                          </tr>
                         
                     
                  </tbody>
              </table>
              </div>
              <div class="d-flex justify-content-center">
                             <a type="submit" onclick="sureToApprove(<?php echo $oid;?>)" name="confirm"class="btn btn-success btn-block btn-sm ">Confirm</a>  
                             <a type="submit" onclick="sureToApproveel(<?php echo $oid;?>)" name="Restack"class="btn  btn-sm btn-outline-primary">Re-Stack</a>  
                             <a type="submit" onclick="sureToApprovee(<?php echo $oid;?>)" name="save"class="btn btn-sm btn-primary">Decline</a>
                            </div>
                           
</section>
                </div>
                </div>
               
</body>
</html>