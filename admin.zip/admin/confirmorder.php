<?php
	include 'includes/config.php';
	$id = $_GET['id'];
		$query = "UPDATE payment SET status = 'confirmed' WHERE order_id = '$id'";
	$result = $conn->query($query);
	if($result == TRUE){
		echo "<script type = \"text/javascript\">
					window.location.href = \"index.php\"
				</script>";
	}
	else {

		echo "<script type = \"text/javascript\">
        alert(\"Not Deleted\");
        window.location.href = \"product.php\"
    </script>";
	}
?>
