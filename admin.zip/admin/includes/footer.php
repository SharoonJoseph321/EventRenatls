<head>

<style>
.center {
    position:sticky;
  text-align: center;
}
</style>

<footer>

<div class="container-fluid center pt-4 px-4">
                <div class="bg-secondary rounded-top p-4">
                    <div class="row">
                        <div class="center col-12 col-xl-6 text-center text-sm-start">
                            &copy; <a text-align="center">Event Essentials</a>, All Right Reserved. 
                        </div>
                        
                    </div>
                </div>
  </div>
</footer>