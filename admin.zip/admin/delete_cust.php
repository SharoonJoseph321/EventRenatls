<?php
	include 'includes/config.php';
	$id = $_REQUEST['id'];
		$query = "DELETE FROM usertb WHERE cust_id = '$id'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\"Successfully Deleted\");
					window.location.href = \"Customers.php\"
				</script>";
	}
	else {

		echo "<script type = \"text/javascript\">
        alert(\"Not Deleted\");
        window.location.href = \"Customers.php\"
    </script>";
	}
?>
