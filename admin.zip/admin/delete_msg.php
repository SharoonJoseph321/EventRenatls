<?php
	include 'includes/config.php';
	$id = $_REQUEST['id'];
		$query = "DELETE FROM feedbacktb WHERE msg_id = '$id'";
	$result = $conn->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\"Message Successfully Send\");
					window.location.href = \"messages.php\"
				</script>";
	}
	else {

		echo "incorrect";
	}
?>
