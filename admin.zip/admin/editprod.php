 
 
 
 <head>
    <meta charset="utf-8">
    <title>Event Essentials</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">



    <style>
    .scontainer{
        
        max-width: 600px;
        margin: auto;
        height: 90vh;

    }
        </style>
 

</head>

 
 
 
 <body>

 
                  <section>
                    <form action="" method="post" enctype="multipart/form-data">
                
                        <div class=" scontainer bg-secondary rounded h-100 p-4">
                            <h6 class="mb-4">Add New product</h6>
                            <div class="mb-3">
                            <label for="cartegory">Choose the Category</label>
                            <select class="form-select mb-3" aria-label="Default select example" name="cname">
                            <?php
								include 'includes/config.php';
								$select = "SELECT * FROM categorytb";
								$result = $conn->query($select);
								while($row = $result->fetch_assoc()){
							?>

                            
                             <option name="category_id" value=<?php echo $row['cat_id'];?> > <?php echo $row['cat_name'];?> </option>
                            <?php

                            
                            ?>
                          
                          <?php
                                }
                                
                                if(isset($_POST['save'])){
                                    include 'includes/config.php';
                                   
                                    $pname = $_POST['pname'];
                                    $qty = $_POST['qty'];
                                    $price = $_POST['price'];
                                    $desc = $_POST['desc'];
                                    $category_id = $_POST['cname'];
                                    $image = basename($_FILES['image']['name']);
                                    $target_path = "../pro_images/";
                                    $target_path = $target_path . basename ($_FILES['image']['name']);
                                    if(move_uploaded_file($_FILES['image']['tmp_name'], $target_path)){
        
                                    $qry = "INSERT INTO itemtb (name,pro_desc,prod_qty,prod_price,prod_image,cat_id)
                                    VALUES('$pname','$desc','$qty','$price','$image','$category_id')";
                                    echo $qry;
                                    $result = $conn->query($qry);
                                    echo $result;
                                    if($result == TRUE){
                                        echo "<script type = \"text/javascript\">
                                                    alert(\"Saved successfully.\");
                                                    window.location = (\"product.php\")
                                                    </script>";
                                   } } else{
                                        echo "<script type = \"text/javascript\">
                                                    alert(\"Not saved Failed. Try Again\");
                                                    window.location = (\"product.php\")
                                                    </script>";
                                    }
                                }
                                
                              
                                ?>
                                </select>
                            </div>



                           <div class="mb-3">
                                <label for="formFileMultiple" class="form-label">Product Name</label>
                                <input class="form-control bg-dark" type="text" name="pname">
                            </div>
                            <div class="mb-3">
                                <label for="formFileMultiple" class="form-label">Price Per day</label>
                                <input class="form-control bg-dark" type="text" name="price">
                            </div>
                            <div class="mb-4">
                                <label for="formFileMultiple" class="form-label">Product Description</label>
                                <input class="form-control bg-dark" type="text" name="desc">
                            </div>
                            <div class="mb-3">
                                <label for="formFileMultiple" class="form-label">Available Quantity</label>
                                <input class="form-control bg-dark" type="text" name="qty">
                            </div>

                            <div class="mb-3">
                                <label for="formFile" class="form-label">Insert Image</label>
                                <input class="form-control bg-dark" type="file"  name="image">
                            </div>
                            <div class="d-flex justify-content-center">
                             <button type="submit" name="save"class="btn btn-success btn-block btn-sm gradient-custom-4 text-body">Save</button>
                            </div>

                        </div>
                  
                    </form>
</section>
</body>