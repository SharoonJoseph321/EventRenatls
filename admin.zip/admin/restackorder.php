<?php
	include 'includes/config.php';
	$id = $_REQUEST['id'];
    $vsql="SELECT order_details.*,itemtb.*
    FROM order_details
    INNER JOIN itemtb ON order_details.product_id=itemtb.product_id AND order_details.order_id='$id' ";
  $result8=$conn->query($vsql);
  while($u=$result8->fetch_assoc()){
  $iqty=$u['pro_qty'];
  $o_qty=$u['prod_qty'];
  $pr=$u['product_id'];
  
    $newqty = $iqty + $o_qty;
    $sele = "UPDATE itemtb SET pro_qty='$newqty' WHERE product_id='$pr'";
    $result4 = $conn->query($sele);
    if ($result4 == TRUE) {
		echo "<script type = \"text/javascript\">
        alert(\"Restacking Success\");
					window.location.href = \"index.php\"
				</script>";
	}
	else {

		echo "<script type = \"text/javascript\">
        alert(\"Restacking Failed\");
        window.location.href = \"orderdet.php\"
    </script>";
	}
}
?>
